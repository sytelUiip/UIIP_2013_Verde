drop sequence SEQUENCE_ID ;

drop trigger ID_TRIGGER;
drop trigger TRIGGER_CAMBIO_USERNAME;
drop trigger TRIGGER1;
drop trigger TRIGGER2;


drop table Notizia;
drop table GestioneAccount;
drop table Account;
drop table GestioneGruppi;
drop table Funzioni;
drop table Gruppo;