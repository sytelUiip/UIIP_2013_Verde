CREATE USER verde IDENTIFIED BY verde ;
GRANT ALL PRIVILEGES TO verde ;
disconnect;
connect verde;