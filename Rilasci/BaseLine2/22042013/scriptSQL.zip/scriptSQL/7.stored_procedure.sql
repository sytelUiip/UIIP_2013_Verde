--------------------------------------------------------
--  DDL for Procedure ANNULLA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."ANNULLA" 
(
  P_ID IN NUMBER  
) AS 
BEGIN
  UPDATE NOTIZIA SET stato='S', lock_notizia='N' WHERE id=P_ID;
  Commit;
END ANNULLA;

/
--------------------------------------------------------
--  DDL for Procedure CAMBIO_GRUPPO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."CAMBIO_GRUPPO" 
(
  P_USERNAME IN VARCHAR2 
,  P_AMMINISTRATORE IN VARCHAR2
, P_GIORNALISTA IN VARCHAR2
) 
AS 
cnt number;
BEGIN
  
  IF p_amministratore='false' THEN
      DELETE FROM GESTIONEACCOUNT
      WHERE ACCOUNT_USERNAME=P_USERNAME
      AND GRUPPO_NOMEGRUPPO='Amministratore'; 
  ELSIF p_amministratore='true' THEN
    SELECT COUNT(*) INTO cnt FROM GESTIONEACCOUNT 
    WHERE ACCOUNT_USERNAME=P_USERNAME
    AND GRUPPO_NOMEGRUPPO='Amministratore'; 
  
    IF cnt=0 THEN
      INSERT INTO GESTIONEACCOUNT VALUES(P_USERNAME,'Amministratore');
    END IF;
  END IF;
  
  IF p_giornalista='false' THEN
      DELETE FROM GESTIONEACCOUNT
      WHERE ACCOUNT_USERNAME=P_USERNAME
      AND GRUPPO_NOMEGRUPPO='Giornalista'; 
  ELSIF p_giornalista='true' THEN
    SELECT COUNT(*) INTO cnt FROM GESTIONEACCOUNT 
    WHERE ACCOUNT_USERNAME=P_USERNAME
    AND GRUPPO_NOMEGRUPPO='Giornalista'; 
  
    IF cnt=0 THEN
      INSERT INTO GESTIONEACCOUNT VALUES(P_USERNAME,'Giornalista');
    END IF;
  END IF;
  
  commit;
END CAMBIO_GRUPPO;

/
--------------------------------------------------------
--  DDL for Procedure CANCELLA_ACCOUNT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."CANCELLA_ACCOUNT" 
(
  P_USERNAME IN VARCHAR2
) AS
BEGIN
  UPDATE ACCOUNT SET stato='C' WHERE username=P_USERNAME;
  COMMIT;
END CANCELLA_ACCOUNT;

/
--------------------------------------------------------
--  DDL for Procedure CANCELLAZIONE_NOTIZIA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."CANCELLAZIONE_NOTIZIA" 
(
  P_ID IN NUMBER  
) AS 
BEGIN
  UPDATE NOTIZIA SET stato='C' WHERE id=P_ID;
  COMMIT;
END CANCELLAZIONE_NOTIZIA;

/
--------------------------------------------------------
--  DDL for Procedure CERCA_ACCOUNT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."CERCA_ACCOUNT" 
(
  P_USERNAME IN VARCHAR2,
  P_CURSOR OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN P_CURSOR FOR
        SELECT * FROM account
        where username=P_USERNAME;        
END CERCA_ACCOUNT;

/
--------------------------------------------------------
--  DDL for Procedure CERCA_FUNZIONI
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."CERCA_FUNZIONI" 
(
  P_TIPO_GRUPPO IN VARCHAR2,
  P_CURSOR OUT SYS_REFCURSOR
)AS 
BEGIN
    OPEN P_CURSOR FOR
    select * from gestionegruppi
    where gruppo_nomegruppo=P_TIPO_GRUPPO;
END CERCA_FUNZIONI;

/
--------------------------------------------------------
--  DDL for Procedure CERCA_GRUPPO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."CERCA_GRUPPO" 
(
  P_USERNAME IN VARCHAR2,
  P_CURSOR OUT SYS_REFCURSOR
)AS 
BEGIN
  OPEN P_CURSOR FOR
    select * from gestioneaccount
    where account_username=p_username;
END CERCA_GRUPPO;

/

--------------------------------------------------------
--  DDL for Procedure CREA_ACCOUNT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."CREA_ACCOUNT" 
(
  P_NOME IN VARCHAR2
, P_COGNOME IN VARCHAR2
, P_USERNAME IN VARCHAR2
, P_PASSWORD IN VARCHAR2
, P_SIGLA_REDAZIONE IN VARCHAR2
, P_SIGLA_GIORNALISTA IN VARCHAR2
, P_TIPO_ACCOUNT IN VARCHAR2 DEFAULT 'Giornalista'
) AS
BEGIN
    INSERT INTO ACCOUNT (nome, cognome, username, password, siglaredazione, siglagiornalista, stato)
    VALUES (P_NOME, P_COGNOME, P_USERNAME, P_PASSWORD, P_SIGLA_REDAZIONE, P_SIGLA_GIORNALISTA,'S');
    INSERT INTO GESTIONEACCOUNT VALUES (P_USERNAME,p_tipo_account);
  COMMIT;
END CREA_ACCOUNT;

/

--------------------------------------------------------
--  DDL for Procedure CREAZIONE_NOTIZIA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."CREAZIONE_NOTIZIA" 
(
  P_TITOLO IN VARCHAR2
, P_SOTTOTITOLO IN VARCHAR2
, P_AUTORE IN VARCHAR2
, P_ULTIMO_DIGITATORE IN VARCHAR2
, P_LUNGHEZZA_TESTO IN NUMBER
, P_TESTO IN NOTIZIA.testo%TYPE
, P_DATACREAZIONE IN VARCHAR2
) AS
BEGIN
  INSERT INTO NOTIZIA (titolo, sottotitolo, autore_sigla, ultimodigitatore_sigla, datacreazione ,lunghezzatesto, testo,stato,lock_notizia)
  VALUES
  (P_TITOLO, P_SOTTOTITOLO, P_AUTORE, P_ULTIMO_DIGITATORE, P_DATACREAZIONE,P_LUNGHEZZA_TESTO, P_TESTO,'S','N');
  commit;
END CREAZIONE_NOTIZIA;

/
--------------------------------------------------------
--  DDL for Procedure LISTA_ACCOUNT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."LISTA_ACCOUNT" (P_CURSOR OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN P_CURSOR FOR
        SELECT * FROM account 
        where stato='S'
        order by username;       
END LISTA_ACCOUNT;

/
--------------------------------------------------------
--  DDL for Procedure LISTA_NOTIZIE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."LISTA_NOTIZIE" (P_CURSOR OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN P_CURSOR FOR 
        SELECT * FROM notizia;
END LISTA_NOTIZIE;

/
--------------------------------------------------------
--  DDL for Procedure MODIFICA_ACCOUNT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."MODIFICA_ACCOUNT" 
(
  P_USERNAME IN VARCHAR2
, P_NOME IN VARCHAR2
, P_COGNOME IN VARCHAR2
, P_SIGLA_REDAZIONE IN VARCHAR2
, P_SIGLA_GIORNALISTA IN VARCHAR2
) AS
BEGIN
  UPDATE ACCOUNT
  SET
  nome=P_NOME, cognome=P_COGNOME, siglaredazione=P_SIGLA_REDAZIONE, siglagiornalista=P_SIGLA_GIORNALISTA
  WHERE username=P_USERNAME;
  COMMIT;
END MODIFICA_ACCOUNT;

/
--------------------------------------------------------
--  DDL for Procedure MODIFICA_NOTIZIA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."MODIFICA_NOTIZIA" 
(
P_ULTIMO_DIGITATORE IN VARCHAR2
, P_ID IN NUMBER
) AS 
BEGIN
  UPDATE NOTIZIA SET lock_notizia='Y', ultimodigitatore_sigla=P_ULTIMO_DIGITATORE
  WHERE id=P_ID;
  commit;
END MODIFICA_NOTIZIA;

/

--------------------------------------------------------
--  DDL for Procedure REGISTRA_NOTIZIE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."REGISTRA_NOTIZIE" 
(
  P_ID IN NUMBER
, P_TITOLO IN VARCHAR2  
, P_SOTTOTITOLO IN VARCHAR2  
, P_LUNGHEZZA_TESTO IN VARCHAR2  
, P_TESTO IN CLOB  
) AS 
BEGIN
  UPDATE NOTIZIA SET titolo=P_TITOLO, sottotitolo=P_SOTTOTITOLO, lunghezzatesto=P_LUNGHEZZA_TESTO, testo=P_TESTO, lock_notizia='N' WHERE id=P_ID;
  COMMIT;
END REGISTRA_NOTIZIE;

/
--------------------------------------------------------
--  DDL for Procedure TRASMETTI_NOTIZIA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."TRASMETTI_NOTIZIA" 
(
  P_ID IN NUMBER  
,  P_DATATRASMISSIONE IN VARCHAR2
) AS 
BEGIN
  UPDATE NOTIZIA SET stato='Q', datatrasmissione=P_DATATRASMISSIONE WHERE id=P_ID;
  COMMIT;
END TRASMETTI_NOTIZIA;

/
--------------------------------------------------------
--  DDL for Procedure VISUALIZZA_NOTIZIA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."VISUALIZZA_NOTIZIA" ( P_ID IN NUMBER , P_CURSOR OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN P_CURSOR FOR 
        SELECT * FROM notizia
        where id=p_id;
END VISUALIZZA_NOTIZIA;

/
