DROP SEQUENCE SEQUENCE_ID;

DROP TABLE Notizia;
DROP TABLE GestioneAccount;
DROP TABLE Account;
DROP TABLE GestioneGruppi;
DROP TABLE Funzioni;
DROP TABLE Gruppo;

