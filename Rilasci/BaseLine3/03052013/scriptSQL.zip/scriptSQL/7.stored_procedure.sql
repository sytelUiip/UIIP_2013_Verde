--------------------------------------------------------
--  DDL for Procedure ANNULLA_NOTIZIA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."ANNULLA_NOTIZIA" 
(
  P_ID IN NUMBER  
) AS 
BEGIN
  UPDATE NOTIZIA SET stato='S', lock_notizia='N', ultimodigitatore_sigla=rollbackdigitatore_sigla WHERE id=P_ID;
  Commit;
END ANNULLA_NOTIZIA;

/
--------------------------------------------------------
--  DDL for Procedure CAMBIO_GRUPPO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."CAMBIO_GRUPPO" (
    P_USERNAME       IN VARCHAR2 ,
    P_AMMINISTRATORE IN VARCHAR2 ,
    P_GIORNALISTA    IN VARCHAR2 )
AS
  cnt NUMBER;
BEGIN
  BEGIN
    IF p_amministratore='false' THEN
      DELETE
      FROM GESTIONEACCOUNT
      WHERE ACCOUNT_USERNAME=P_USERNAME
      AND GRUPPO_NOMEGRUPPO ='Amministratore';
    ELSIF p_amministratore  ='true' THEN
      SELECT COUNT(*)
      INTO cnt
      FROM GESTIONEACCOUNT
      WHERE ACCOUNT_USERNAME=P_USERNAME
      AND GRUPPO_NOMEGRUPPO ='Amministratore';
      IF cnt                =0 THEN
        INSERT INTO GESTIONEACCOUNT VALUES
          (P_USERNAME,'Amministratore'
          );
      END IF;
    END IF;
  EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    RETURN;
  END;
  BEGIN
    IF p_giornalista='false' THEN
      DELETE
      FROM GESTIONEACCOUNT
      WHERE ACCOUNT_USERNAME=P_USERNAME
      AND GRUPPO_NOMEGRUPPO ='Giornalista';
    ELSIF p_giornalista     ='true' THEN
      SELECT COUNT(*)
      INTO cnt
      FROM GESTIONEACCOUNT
      WHERE ACCOUNT_USERNAME=P_USERNAME
      AND GRUPPO_NOMEGRUPPO ='Giornalista';
      IF cnt                =0 THEN
        INSERT INTO GESTIONEACCOUNT VALUES
          (P_USERNAME,'Giornalista'
          );
      END IF;
    END IF;
  EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    RETURN;
  END;
  COMMIT;
END CAMBIO_GRUPPO;

/
--------------------------------------------------------
--  DDL for Procedure CANCELLA_ACCOUNT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."CANCELLA_ACCOUNT" 
(
  P_USERNAME IN VARCHAR2
) AS
BEGIN
  UPDATE ACCOUNT SET stato='C' WHERE username=P_USERNAME;
  COMMIT;
END CANCELLA_ACCOUNT;

/
--------------------------------------------------------
--  DDL for Procedure CANCELLAZIONE_NOTIZIA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."CANCELLAZIONE_NOTIZIA" 
(
  P_ID IN NUMBER  
) AS 
BEGIN
  UPDATE NOTIZIA SET stato='C' WHERE id=P_ID;
  COMMIT;
END CANCELLAZIONE_NOTIZIA;

/
--------------------------------------------------------
--  DDL for Procedure CERCA_ACCOUNT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."CERCA_ACCOUNT" 
(
  P_USERNAME IN VARCHAR2,
  P_CURSOR OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN P_CURSOR FOR
        SELECT * FROM account
        where username=P_USERNAME;        
END CERCA_ACCOUNT;

/
--------------------------------------------------------
--  DDL for Procedure CERCA_FUNZIONI
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."CERCA_FUNZIONI" 
(
  P_TIPO_GRUPPO IN VARCHAR2,
  P_CURSOR OUT SYS_REFCURSOR
)AS 
BEGIN
    OPEN P_CURSOR FOR
    select * from gestionegruppi
    where gruppo_nomegruppo=P_TIPO_GRUPPO;
END CERCA_FUNZIONI;

/
--------------------------------------------------------
--  DDL for Procedure CERCA_GRUPPO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."CERCA_GRUPPO" 
(
  P_USERNAME IN VARCHAR2,
  P_CURSOR OUT SYS_REFCURSOR
)AS 
BEGIN
  OPEN P_CURSOR FOR
    select * from gestioneaccount
    where account_username=p_username;
END CERCA_GRUPPO;

/
--------------------------------------------------------
--  DDL for Procedure CERCA_NOTIZIE_TRASMISSIBILI
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."CERCA_NOTIZIE_TRASMISSIBILI" 
(
   P_CURSOR OUT SYS_REFCURSOR
)
AS 
BEGIN
 OPEN P_CURSOR FOR
    select * from NOTIZIA
    where STATO='Q';
END CERCA_NOTIZIE_TRASMISSIBILI;

/
--------------------------------------------------------
--  DDL for Procedure CONTROLLO_MODIFICA_NOTIZIA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."CONTROLLO_MODIFICA_NOTIZIA" 
( 
  P_ID IN NUMBER  
, P_SIGLA_AUTORE IN VARCHAR2  
, P_CURSOR OUT SYS_REFCURSOR
) AS 
BEGIN
    OPEN P_CURSOR FOR
        SELECT * FROM NOTIZIA
        where ID=P_ID
        AND STATO='S'
        AND (LOCK_NOTIZIA='N' OR 
                  (LOCK_NOTIZIA='Y' 
                  AND 
                  ULTIMODIGITATORE_SIGLA=P_SIGLA_AUTORE)   );   
END CONTROLLO_MODIFICA_NOTIZIA;

/
--------------------------------------------------------
--  DDL for Procedure COUNT_PER_AUTORE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."COUNT_PER_AUTORE" 
(
  P_AUTORE IN VARCHAR2  
, P_COUNT OUT NUMBER  
) AS 
BEGIN
  SELECT COUNT(*) INTO P_COUNT  
      FROM NOTIZIA 
      WHERE lower(NOTIZIA.AUTORE_SIGLA) LIKE lower('%' || P_AUTORE || '%'  );
END COUNT_PER_AUTORE;

/
--------------------------------------------------------
--  DDL for Procedure COUNT_PER_STATO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."COUNT_PER_STATO" 
(
  P_STATO IN VARCHAR2  
, P_COUNT OUT NUMBER  
) AS 
BEGIN
      SELECT COUNT(*)  INTO P_COUNT 
      FROM NOTIZIA 
      WHERE lower(NOTIZIA.STATO)=lower(P_STATO);
END COUNT_PER_STATO;

/
--------------------------------------------------------
--  DDL for Procedure COUNT_PER_TITOLO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."COUNT_PER_TITOLO" 
(
  P_TITOLO IN VARCHAR2  
, P_COUNT OUT NUMBER  
) AS 
BEGIN
      SELECT COUNT(*) INTO P_COUNT
      FROM NOTIZIA
      WHERE lower(NOTIZIA.TITOLO) LIKE lower('%' || P_TITOLO  || '%');
END COUNT_PER_TITOLO;

/
--------------------------------------------------------
--  DDL for Procedure CREA_ACCOUNT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."CREA_ACCOUNT" (
    P_NOME              IN VARCHAR2 ,
    P_COGNOME           IN VARCHAR2 ,
    P_USERNAME          IN VARCHAR2 ,
    P_PASSWORD          IN VARCHAR2 ,
    P_SIGLA_REDAZIONE   IN VARCHAR2 ,
    P_SIGLA_GIORNALISTA IN VARCHAR2 ,
    P_TIPO_ACCOUNT      IN VARCHAR2 DEFAULT 'Giornalista' )
AS
BEGIN
  BEGIN
    INSERT
    INTO ACCOUNT
      (
        nome,
        cognome,
        username,
        password,
        siglaredazione,
        siglagiornalista,
        stato
      )
      VALUES
      (
        P_NOME,
        P_COGNOME,
        P_USERNAME,
        P_PASSWORD,
        P_SIGLA_REDAZIONE,
        P_SIGLA_GIORNALISTA,
        'S'
      );
  EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    RETURN;
  END;
  BEGIN
    INSERT INTO GESTIONEACCOUNT VALUES
      (P_USERNAME,p_tipo_account
      );
  EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    RETURN;
  END;
  COMMIT;
END CREA_ACCOUNT;

/
--------------------------------------------------------
--  DDL for Procedure CREAZIONE_NOTIZIA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."CREAZIONE_NOTIZIA" 
(
  P_TITOLO IN VARCHAR2
, P_SOTTOTITOLO IN VARCHAR2
, P_AUTORE IN VARCHAR2
, P_ULTIMO_DIGITATORE IN VARCHAR2
, P_LUNGHEZZA_TESTO IN NUMBER
, P_TESTO IN NOTIZIA.testo%TYPE
, P_DATACREAZIONE IN VARCHAR2
) AS
BEGIN
  INSERT INTO NOTIZIA (titolo, sottotitolo, autore_sigla, ultimodigitatore_sigla, datacreazione ,lunghezzatesto, testo,stato,lock_notizia)
  VALUES
  (P_TITOLO, P_SOTTOTITOLO, P_AUTORE, P_ULTIMO_DIGITATORE, P_DATACREAZIONE,P_LUNGHEZZA_TESTO, P_TESTO,'S','N');
  commit;
END CREAZIONE_NOTIZIA;

/
--------------------------------------------------------
--  DDL for Procedure FILTRA_PER_AUTORE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."FILTRA_PER_AUTORE" 
(
    P_AUTORE IN VARCHAR2,
    P_MIN    IN INTEGER,
    P_MAX    IN INTEGER,
    P_CURSOR OUT SYS_REFCURSOR
)

AS
BEGIN 
  OPEN P_CURSOR 
  FOR
  SELECT * FROM
  (SELECT e.*,   ROWNUM rnum
   FROM
    (
      SELECT ID,STATO,LOCK_NOTIZIA,TITOLO,SOTTOTITOLO,AUTORE_SIGLA,ULTIMODIGITATORE_SIGLA,DATACREAZIONE,DATATRASMISSIONE,LUNGHEZZATESTO  
      FROM NOTIZIA 
      WHERE lower(NOTIZIA.AUTORE_SIGLA) LIKE lower('%' || P_AUTORE || '%'  )
      ORDER BY NOTIZIA.DATACREAZIONE DESC
      ) e
   WHERE ROWNUM <=P_MAX ) 
  WHERE rnum >=P_MIN;

END FILTRA_PER_AUTORE;

/
--------------------------------------------------------
--  DDL for Procedure FILTRA_PER_STATO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."FILTRA_PER_STATO" 
(

P_STATO IN VARCHAR2,
P_MIN    IN INTEGER,
P_MAX    IN INTEGER,
P_CURSOR OUT SYS_REFCURSOR
)

AS
BEGIN 
  OPEN P_CURSOR 
  FOR
  SELECT * FROM
  (SELECT e.*,   ROWNUM rnum
   FROM
    (
      SELECT ID,STATO,LOCK_NOTIZIA,TITOLO,SOTTOTITOLO,AUTORE_SIGLA,ULTIMODIGITATORE_SIGLA,DATACREAZIONE,DATATRASMISSIONE,LUNGHEZZATESTO  
      FROM NOTIZIA 
      WHERE lower(NOTIZIA.STATO)=lower(P_STATO)
      ORDER BY NOTIZIA.DATACREAZIONE DESC
    ) e
   WHERE ROWNUM <=P_MAX ) 
  WHERE rnum >=P_MIN;
END FILTRA_PER_STATO;

/
--------------------------------------------------------
--  DDL for Procedure FILTRA_PER_TITOLO
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."FILTRA_PER_TITOLO" (
    P_TITOLO IN VARCHAR2,
    P_MIN    IN INTEGER,
    P_MAX    IN INTEGER,
    P_CURSOR OUT SYS_REFCURSOR )
AS
BEGIN
  OPEN P_CURSOR FOR 
  SELECT * FROM
  (SELECT e.*,   ROWNUM rnum
   FROM
    (
      SELECT ID, STATO, LOCK_NOTIZIA, TITOLO, SOTTOTITOLO, AUTORE_SIGLA, ULTIMODIGITATORE_SIGLA, DATACREAZIONE, DATATRASMISSIONE, LUNGHEZZATESTO
      FROM NOTIZIA
      WHERE lower(NOTIZIA.TITOLO) LIKE lower('%' || P_TITOLO  || '%')
      ORDER BY NOTIZIA.DATACREAZIONE DESC 
    ) e
   WHERE ROWNUM <=P_MAX ) 
  WHERE rnum >=P_MIN;
END FILTRA_PER_TITOLO;

/
--------------------------------------------------------
--  DDL for Procedure LISTA_ACCOUNT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."LISTA_ACCOUNT" (P_CURSOR OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN P_CURSOR FOR
        SELECT * FROM account 
        where stato='S'
        order by username;       
END LISTA_ACCOUNT;

/
--------------------------------------------------------
--  DDL for Procedure LISTA_NOTIZIE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."LISTA_NOTIZIE" (P_CURSOR OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN P_CURSOR FOR 
        SELECT ID,STATO,LOCK_NOTIZIA,TITOLO,SOTTOTITOLO,AUTORE_SIGLA,ULTIMODIGITATORE_SIGLA,DATACREAZIONE,DATATRASMISSIONE,LUNGHEZZATESTO FROM notizia;
END LISTA_NOTIZIE;

/
--------------------------------------------------------
--  DDL for Procedure MODIFICA_ACCOUNT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."MODIFICA_ACCOUNT" 
(
  P_USERNAME IN VARCHAR2
, P_NOME IN VARCHAR2
, P_COGNOME IN VARCHAR2
, P_SIGLA_REDAZIONE IN VARCHAR2
, P_SIGLA_GIORNALISTA IN VARCHAR2
) AS
BEGIN
  UPDATE ACCOUNT
  SET
  nome=P_NOME, cognome=P_COGNOME, siglaredazione=P_SIGLA_REDAZIONE, siglagiornalista=P_SIGLA_GIORNALISTA
  WHERE username=P_USERNAME;
  COMMIT;
END MODIFICA_ACCOUNT;

/
--------------------------------------------------------
--  DDL for Procedure MODIFICA_NOTIZIA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."MODIFICA_NOTIZIA" (
    P_ID                IN NUMBER ,
    P_ULTIMO_DIGITATORE IN VARCHAR2 )
AS
  cnt NUMBER;
BEGIN
  SELECT COUNT(*) INTO cnt FROM NOTIZIA WHERE id=P_ID AND lock_notizia='Y';
  IF cnt=0 THEN
    BEGIN
      UPDATE NOTIZIA
      SET ROLLBACKDIGITATORE_SIGLA=ultimodigitatore_sigla
      WHERE id                    =P_ID;
    EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      RETURN;
    END;
  END IF;
  BEGIN
    UPDATE NOTIZIA
    SET lock_notizia        ='Y',
      ultimodigitatore_SIGLA=P_ULTIMO_DIGITATORE
    WHERE id                =P_ID;
  EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    RETURN;
  END;
  COMMIT;
END MODIFICA_NOTIZIA;

/
--------------------------------------------------------
--  DDL for Procedure NOTIZIA_TRASMESSA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."NOTIZIA_TRASMESSA" 
(
   P_ID IN NUMBER  

) AS 
BEGIN
  UPDATE NOTIZIA SET stato='T' WHERE id=P_ID;
  COMMIT;
END NOTIZIA_TRASMESSA;

/
--------------------------------------------------------
--  DDL for Procedure REGISTRA_NOTIZIA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."REGISTRA_NOTIZIA" 
(
  P_ID IN NUMBER,
  P_TITOLO IN VARCHAR2,
  P_SOTTOTITOLO IN VARCHAR2,
  P_LUNGHEZZA_TESTO IN VARCHAR2,
  P_TESTO IN CLOB  
) AS 
BEGIN
  UPDATE NOTIZIA SET titolo=P_TITOLO, sottotitolo=P_SOTTOTITOLO, lunghezzatesto=P_LUNGHEZZA_TESTO, testo=P_TESTO, lock_notizia='N' WHERE id=P_ID;
  COMMIT;
END REGISTRA_NOTIZIA;

/
--------------------------------------------------------
--  DDL for Procedure SBLOCCA_NOTIZIE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."SBLOCCA_NOTIZIE" 
(
  P_SIGLA_GIORNALISTA IN VARCHAR2  
) AS 
BEGIN
  UPDATE NOTIZIA SET stato='S', lock_notizia='N', ultimodigitatore_sigla=rollbackdigitatore_sigla 
  WHERE ULTIMODIGITATORE_SIGLA=P_SIGLA_GIORNALISTA AND lock_notizia='Y';
  Commit;
END SBLOCCA_NOTIZIE;

/
--------------------------------------------------------
--  DDL for Procedure TRASMETTI_NOTIZIA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."TRASMETTI_NOTIZIA" 
(
  P_ID IN NUMBER,
  P_DATATRASMISSIONE IN VARCHAR2
) AS 
BEGIN
  UPDATE NOTIZIA SET stato='Q', datatrasmissione=P_DATATRASMISSIONE WHERE id=P_ID;
  COMMIT;
END TRASMETTI_NOTIZIA;

/
--------------------------------------------------------
--  DDL for Procedure VISUALIZZA_NOTIZIA
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "VERDE"."VISUALIZZA_NOTIZIA" 
(
  P_ID IN NUMBER,  
  P_CURSOR OUT SYS_REFCURSOR
  )
AS
BEGIN
    OPEN P_CURSOR FOR 
        SELECT * FROM notizia
        where id=P_ID;
END VISUALIZZA_NOTIZIA;

/
