drop sequence SEQUENCE_ID ;

drop trigger ID_TRIGGER;
drop trigger TRIGGER_CAMBIO_USERNAME;
drop trigger TRIGGER1;
drop trigger TRIGGER2;


drop table Notizia;
drop table GestioneAccount;
drop table Account;
drop table GestioneGruppi;
drop table Funzioni;
drop table Gruppo;

drop procedure ANNULLA;
drop procedure CANCELLA_ACCOUNT;
drop procedure CANCELLAZIONE_NOTIZIA;
drop procedure CREA_ACCOUNT;
drop procedure CREAZIONE_NOTIZIA; 
drop procedure MODIFICA_ACCOUNT;
drop procedure MODIFICA_NOTIZIA;
drop procedure REGISTRA_NOTIZIE;
drop procedure TRASMETTI_NOTIZIA;
drop procedure LISTA_ACCOUNT;
drop procedure LISTA_NOTIZIE;
drop procedure VISUALIZZA_NOTIZIA;